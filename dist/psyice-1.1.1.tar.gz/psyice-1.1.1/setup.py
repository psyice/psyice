#!/usr/bin/env python3

from distutils.core import setup

setup(
    name        = 'psyice',
    version     = '1.1.1',
    py_modules  = ['psyice'],
    author      = 'psyice',
    author_email= 'synthetic_ice@yahoo.com',
    url         = 'http://siceprd.top',
    description = 'Psyice\'s personal tool set'
)
