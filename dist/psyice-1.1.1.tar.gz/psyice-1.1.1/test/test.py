#!/usr/bin/env python

import psyice
import os


fuck = [1, 2, 3, [1, 2, [1 , 3 , 5]]];
psyice.printList(fuck, dest=open("./target", "w"))
